﻿using System.ComponentModel.DataAnnotations;

namespace AlexG2Day1_APIs.Validations;

public class OpenDateValidationAttribute : ValidationAttribute
{
    public override bool IsValid(object? value)
    {
        return value is DateTime date && date <= DateTime.Now;
    }

    //public override bool IsValid(object? value)
    //{
    //    var date = (DateTime)value;
    //    if (date <= DateTime.Now)
    //        return true;
    //    else
    //        return false;
    //}
}

