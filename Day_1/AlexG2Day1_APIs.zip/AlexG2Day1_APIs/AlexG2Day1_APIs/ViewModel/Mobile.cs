﻿namespace AlexG2Day1_APIs.ViewModel;

public class Mobile
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
}
