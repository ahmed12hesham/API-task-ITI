﻿using AlexG2Day1_APIs.Validations;
using System.ComponentModel.DataAnnotations;

namespace AlexG2Day1_APIs.Models;

public class Shop
{
    [Range(1, int.MaxValue)]
    public int Id { get; set; }

    [StringLength(10)]
    public string Name { get; set; } = "";

    [OpenDateValidation]
    public DateTime OpenDate { get; set; }

    //[RegularExpression("^(EG|USA|KSA|UAE)$")]
    //[Required]
    public string Location { get; set; } = "";
}

/*
 Fluent Validation
 */