﻿using AlexG2Day1_APIs.ViewModel;
using Microsoft.AspNetCore.Mvc;

namespace AlexG2Day1_APIs.Controllers;

[Route("api/[controller]")]
[ApiController]
public class MobilesController : ControllerBase
{
    private static Dictionary<int, string> mobilesDictionary = new()
    {
        { 0, "HTC" },
        { 1, "Oppo" },
        { 2, "IPhone" },
        { 3, "Samsung" },
        { 4, "OnePlus" },
    };

    [HttpGet]
    public ActionResult<List<string>> GetAll()
    {
        return mobilesDictionary.Values.ToList();
    }

    [HttpGet]
    [Route("{id:int:min(1):max(100)}")]
    public ActionResult<string> GetById(int id)
    {
        if (!mobilesDictionary.ContainsKey(id))
        {
            return NotFound("The mobile isn't found");
        }
        return mobilesDictionary[id];
    }

    [HttpPost]
    public ActionResult Add(Mobile mobile)
    {
        if (mobilesDictionary.ContainsKey(mobile.Id))
        {
            return BadRequest("The mobile already exists");
        }

        mobilesDictionary[mobile.Id] = mobile.Name;
        //return StatusCode(StatusCodes.Status201Created, new { Message = "The mobile has been added" });
        return CreatedAtAction(
            "GetById",
            new { id = mobile.Id },
            new { Message = "The mobile has been added" });
    }

    [HttpPut]
    [Route("{id:int}")]
    public ActionResult Edit(Mobile mobile, int id)
    {
        if (mobile.Id != id)
        {
            return BadRequest();
        }

        if (!mobilesDictionary.ContainsKey(id))
        {
            return NotFound();
        }

        mobilesDictionary[id] = mobile.Name;

        return NoContent();
    }

    [HttpDelete]
    [Route("{id:int}")]
    public ActionResult Delete(int id)
    {
        if (!mobilesDictionary.ContainsKey(id))
        {
            return NotFound();
        }
        mobilesDictionary.Remove(id);

        return NoContent();
    }
}
