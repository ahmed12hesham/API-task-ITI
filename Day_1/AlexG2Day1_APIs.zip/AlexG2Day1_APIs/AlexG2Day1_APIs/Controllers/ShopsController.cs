﻿using AlexG2Day1_APIs.Filters;
using AlexG2Day1_APIs.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AlexG2Day1_APIs.Controllers;

[Route("api/[controller]")]
[ApiController]
public class ShopsController : ControllerBase
{
    private static List<Shop> _shops = new();
    private readonly ILogger<ShopsController> _logger;

    public ShopsController(ILogger<ShopsController> logger)
    {
        _logger = logger;
    }

    [HttpGet]
    public ActionResult<List<Shop>> GetAll()
    {
        return _shops;
    }

    [HttpPost]
    [Route("V1")]
    public ActionResult Add(Shop shop)
    {
        if (!ModelState.IsValid)
        {
            _logger.LogDebug("I am debugging");
            _logger.LogError(ModelState.ErrorCount.ToString());
            return BadRequest(new { Message = "something went wrong" });
        }
        _shops.Add(shop);
        return Ok();
    }

    [HttpPut]
    [Route("V1")]
    public ActionResult Edit(Shop shio)
    {
        return Ok();
    }

    [HttpPost]
    [ShopLocationValidation]
    [Route("V2")]
    public ActionResult AddV2(Shop shop)
    {
        if (!ModelState.IsValid)
        {
            _logger.LogDebug("I am debugging");
            _logger.LogError(ModelState.ErrorCount.ToString());
            return BadRequest(new { Message = "something went wrong" });
        }
        _shops.Add(shop);
        return Ok();
    }


    [HttpPut]
    [ShopLocationValidation]
    [Route("V2")]
    public ActionResult EditV2(Shop shio)
    {
        return Ok();
    }
}
