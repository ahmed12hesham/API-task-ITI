﻿using AlexG2Day1_APIs.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Text.RegularExpressions;

namespace AlexG2Day1_APIs.Filters;

public class ShopLocationValidationAttribute : ActionFilterAttribute
{
    public override void OnActionExecuting(ActionExecutingContext context)
    {
        base.OnActionExecuting(context);

        var allowedLocationsRegex = new Regex("^(EG|USA|KSA|UAE)$");
        Shop? shop = context.ActionArguments["shop"] as Shop;

        if (shop is null || !allowedLocationsRegex.IsMatch(shop.Location))
        {
            // Exit with BadRequest
            context.Result = new BadRequestObjectResult(new { LocationError = "Location is not correct" });
        }
    }
}
