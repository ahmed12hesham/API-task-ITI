﻿
using SideNotes;

Console.WriteLine(GetEmployeeSalary(new Employee
{
    Name = "Marwan",
    Salary = 80000
}));




static int GetEmployeeSalary(Employee employee)
{
    return employee;
}