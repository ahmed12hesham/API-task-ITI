﻿namespace SideNotes;

internal class Employee
{
    public string Name { get; set; } ="";
    public int Salary { get; set; }

    public static implicit operator int (Employee employee)
    {
        return employee.Salary;
    }
}
