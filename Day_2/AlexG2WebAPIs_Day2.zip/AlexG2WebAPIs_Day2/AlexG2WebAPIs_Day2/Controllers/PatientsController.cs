﻿using Hospital.BL;
using Hospital.DAL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AlexG2WebAPIs_Day2.Controllers;

[Route("api/[controller]")]
[ApiController]
public class PatientsController : ControllerBase
{
    private readonly HospitalContext _context;
    private readonly IPatientsManager _patientsManager;

    public PatientsController(HospitalContext context, IPatientsManager patientsManager)
    {
        _context = context;
        _patientsManager = patientsManager;
    }

    [HttpGet]
    public ActionResult<List<PatientReadDTO>> GetAll()
    {
        return _patientsManager.GetAllWithIssues();
    }

    [HttpGet]
    [Route("with_doctor")]
    public ActionResult<List<PatientWithDoctorReadDTO>> GetAllwithDoctor()
    {
        return _patientsManager.GetAllWithDoctor();
    }
    
    
    [HttpPost]
    [Route("Issues")]
    public ActionResult AssignIssuesToPatient(AssignIssuesDTO input)
    {
        _patientsManager.AssignIssuesToPatient(input);
        return NoContent();
    }
}
