﻿using Hospital.BL;
using Microsoft.AspNetCore.Mvc;

namespace AlexG2WebAPIs_Day2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorsController : ControllerBase
    {
        private readonly IDoctorsManager _doctorsManager;

        public DoctorsController(IDoctorsManager doctorsManager)
        {
            _doctorsManager = doctorsManager;
        }

        [HttpGet]
        public ActionResult<IEnumerable<DoctorReadDTO>> GetDoctors()
        {
            return _doctorsManager.GetAllDoctors();
        }

        [HttpGet]
        [Route("{id:Guid}")]
        public ActionResult<DoctorReadDTO> GetDoctor(Guid id)
        {
            var doctorDTO = _doctorsManager.GetDoctorById(id);

            if (doctorDTO == null)
            {
                return NotFound();
            }

            return doctorDTO;
        }

        [HttpPut]
        public ActionResult PutDoctor(DoctorWriteDTO doctorDTO)
        {
            var result = _doctorsManager.EditDoctor(doctorDTO);
            if (result)
            {
                return NoContent();
            }
            return BadRequest();
        }

        [HttpPost]
        public ActionResult<DoctorReadDTO> PostDoctor(DoctorWriteDTO doctor)
        {
            var doctorReadDTO = _doctorsManager.AddDoctor(doctor);
            return CreatedAtAction("GetDoctor", new { id = doctorReadDTO.Id }, doctorReadDTO);
        }

        [HttpDelete("{id}")]
        public ActionResult DeleteDoctor(Guid id)
        {
            _doctorsManager.Delete(id);
            return NoContent();
        }
    }
}
