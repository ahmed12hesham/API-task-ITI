﻿namespace Hospital.BL;

public class AssignIssuesDTO
{
    public Guid PatientId { get; set; }
    public List<Guid> IssuesIds { get; set; } = new();
}
