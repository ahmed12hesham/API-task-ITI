﻿namespace Hospital.BL;

public class PatientWithDoctorReadDTO
{
    public Guid Id { get; set; }
    public string Name { get; set; } = "";
    public DoctorChildReadDTO? Doctor { get; set; }
}
