﻿namespace Hospital.BL;

public class DoctorChildReadDTO
{
    public Guid Id { get; set; }
    public string Name { get; set; } = "";
}

