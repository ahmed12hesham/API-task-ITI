﻿namespace Hospital.BL;

public class DoctorHRReadDTO
{
    public Guid Id { get; set; }
    public string Name { get; set; } = "";
    public string Specialization { get; set; } = "";
    public int PerformanceRate { get; set; }
    public decimal Salary { get; set; }
}
