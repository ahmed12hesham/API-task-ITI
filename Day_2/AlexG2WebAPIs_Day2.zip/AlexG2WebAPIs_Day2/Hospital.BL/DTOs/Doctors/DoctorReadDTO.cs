﻿namespace Hospital.BL;

public class DoctorReadDTO
{
    public Guid Id { get; set; }
    public string Name { get; set; } = "";
    public string Specialization { get; set; } = "";
    public int PerformanceRate { get; set; }
}
