﻿namespace Hospital.BL;

public class DoctorWriteDTO
{
    public Guid Id { get; set; }
    public string Name { get; set; } = "";
    public string Specialization { get; set; } = "";
    public decimal Salary { get; set; }
}
