﻿namespace Hospital.BL;

public class IssueChildReadDTO
{
    public Guid Id { get; set; }
    public string Name { get; set; } = "";
}

