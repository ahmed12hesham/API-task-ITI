﻿namespace Hospital.BL;

public interface IDoctorsManager
{
    public List<DoctorReadDTO> GetAllDoctors();
    DoctorReadDTO? GetDoctorById(Guid id);
    DoctorReadDTO AddDoctor(DoctorWriteDTO doctor);
    bool EditDoctor(DoctorWriteDTO doctor);
    void Delete(Guid id);
}
