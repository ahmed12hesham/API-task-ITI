﻿using AutoMapper;
using Hospital.DAL;
using Microsoft.EntityFrameworkCore;

namespace Hospital.BL;

public class DoctorsManager : IDoctorsManager
{
    private readonly IDoctorsRepo _doctorsRepo;
    private readonly IMapper _mapper;

    public DoctorsManager(IDoctorsRepo doctorsRepo, IMapper mapper)
    {
        _doctorsRepo = doctorsRepo;
        _mapper = mapper;
    }

    public List<DoctorReadDTO> GetAllDoctors()
    {
        //return _doctorsRepo.GetAll().
        //    Select(d => new DoctorReadDTO
        //    {
        //        Id = d.Id,
        //        Name = d.Name,
        //        PerformanceRate = d.PerformanceRate,
        //        Specialization = d.Specialization
        //    }).ToList();

        var dbDoctors = _doctorsRepo.GetAll();
        var dTOList = _mapper.Map<List<DoctorReadDTO>>(dbDoctors);
        return dTOList;
    }

    public DoctorReadDTO? GetDoctorById(Guid id)
    {
        var dbDoctor = _doctorsRepo.GetById(id);
        if (dbDoctor is null)
            return null;
        return _mapper.Map<DoctorReadDTO>(dbDoctor);

        //return new DoctorReadDTO
        //{
        //    Id = dbDoctor.Id,
        //    Name = dbDoctor.Name,
        //    PerformanceRate = dbDoctor.PerformanceRate,
        //    Specialization = dbDoctor.Specialization
        //};
    }

    public DoctorReadDTO AddDoctor(DoctorWriteDTO doctorDTO)
    {
        var dbDoctor = _mapper.Map<Doctor>(doctorDTO);

        dbDoctor.Id = Guid.NewGuid();
        _doctorsRepo.Add(dbDoctor);
        _doctorsRepo.SaveChanges();

        return _mapper.Map<DoctorReadDTO>(dbDoctor);
    }

    public bool EditDoctor(DoctorWriteDTO doctorDTO)
    {
        var dbDoctor = _doctorsRepo.GetById(doctorDTO.Id);
        if (dbDoctor is null)
            return false;
        // transfer data from doctorDTO to dbDoctor wihtout creating a new object
        //dbDoctor.Name = doctorDTO.Name;
        //dbDoctor.Salary = doctorDTO.Salary;
        //dbDoctor.Specialization = doctorDTO.Specialization;
        _mapper.Map(doctorDTO, dbDoctor);
        _doctorsRepo.Update(dbDoctor);
        _doctorsRepo.SaveChanges();

        return true;
    }

    public void Delete(Guid id)
    {
        var dbDoctor = _doctorsRepo.GetById(id);
        if (dbDoctor is null)
            return;
        _doctorsRepo.Delete(dbDoctor);
        _doctorsRepo.SaveChanges();
    }
}
