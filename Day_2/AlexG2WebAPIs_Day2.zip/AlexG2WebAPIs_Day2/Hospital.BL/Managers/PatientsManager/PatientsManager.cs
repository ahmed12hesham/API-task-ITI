﻿using AutoMapper;
using Hospital.DAL;

namespace Hospital.BL;

public class PatientsManager : IPatientsManager
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;

    public PatientsManager(IUnitOfWork unitOfWork, IMapper mapper)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
    }

    public List<PatientReadDTO> GetAllWithIssues()
    {
        var dbPatients = _unitOfWork.PatientRepo.GetAllWithIssues();
        return _mapper.Map<List<PatientReadDTO>>(dbPatients);
    }

    public List<PatientWithDoctorReadDTO> GetAllWithDoctor()
    {
        //var dbPatients = _patientsRepo.GetAllWithDoctor();
        var dbPatients = _unitOfWork.PatientRepo.GetAllWithDoctor();
        return _mapper.Map<List<PatientWithDoctorReadDTO>>(dbPatients);
    }

    public void AssignIssuesToPatient(AssignIssuesDTO input)
    {
        //1. Get Patient
        var patient = _unitOfWork.PatientRepo.GetWithIssues(input.PatientId);
        if (patient == null)
            return;

        //2. Remove existing issues
        patient.Issues.Clear();

        //3. Get Required Issues By Issues Ids
        var requiredIssues = _unitOfWork.IssuesRepo.GetByIssuesIds(input.IssuesIds);

        //4. Assign Issues to Patient
        patient.Issues = requiredIssues;

        _unitOfWork.SaveChanges();
    }
}
