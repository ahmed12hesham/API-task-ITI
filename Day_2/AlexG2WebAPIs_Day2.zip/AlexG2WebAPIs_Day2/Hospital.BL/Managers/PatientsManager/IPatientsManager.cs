﻿namespace Hospital.BL;

public interface IPatientsManager
{
    List<PatientReadDTO> GetAllWithIssues();
    List<PatientWithDoctorReadDTO> GetAllWithDoctor();
    void AssignIssuesToPatient(AssignIssuesDTO input);
}
