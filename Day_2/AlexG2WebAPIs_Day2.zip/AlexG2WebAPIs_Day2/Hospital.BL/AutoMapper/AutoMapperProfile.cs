﻿using AutoMapper;
using Hospital.DAL;

namespace Hospital.BL;

public class AutoMapperProfile : Profile
{
    public AutoMapperProfile()
    {
        CreateMap<Doctor, DoctorReadDTO>();
        CreateMap<Doctor, DoctorHRReadDTO>(); // Not used for explaining only
        CreateMap<DoctorWriteDTO, Doctor>();

        CreateMap<Patient, PatientReadDTO>();
        CreateMap<Issue, IssueChildReadDTO>();

        CreateMap<Patient, PatientWithDoctorReadDTO>();
        CreateMap<Doctor, DoctorChildReadDTO>();
    }
}
