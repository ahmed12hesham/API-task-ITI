﻿namespace Hospital.DAL;

public class UnitOfWork : IUnitOfWork
{
    private readonly HospitalContext _context;

    public IDoctorsRepo DoctorsRepo { get; }
    public IPatientsRepo PatientRepo { get; }
    public IIssuesRepo IssuesRepo { get; }

    public UnitOfWork(IDoctorsRepo doctorsRepo, IPatientsRepo patientRepo, IIssuesRepo issuesRepo, HospitalContext context)
    {
        DoctorsRepo = doctorsRepo;
        PatientRepo = patientRepo;
        IssuesRepo = issuesRepo;
        _context = context;
    }

    public void SaveChanges()
    {
        _context.SaveChanges();
    }
}
