﻿namespace Hospital.DAL;

public interface IUnitOfWork
{
    public IDoctorsRepo DoctorsRepo { get; }
    public IPatientsRepo PatientRepo { get; }
    public IIssuesRepo IssuesRepo { get; }

    void SaveChanges();
}
