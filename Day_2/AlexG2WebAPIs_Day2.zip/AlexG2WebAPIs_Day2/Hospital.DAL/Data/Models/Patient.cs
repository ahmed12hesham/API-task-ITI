﻿namespace Hospital.DAL;

public class Patient
{
    public Guid Id { get; set; }
    public string Name { get; set; } = "";
    public Guid? DoctorId { get; set; }
    public ICollection<Issue> Issues { get; set; } = new HashSet<Issue>();
    public Doctor? Doctor { get; set; }
}
