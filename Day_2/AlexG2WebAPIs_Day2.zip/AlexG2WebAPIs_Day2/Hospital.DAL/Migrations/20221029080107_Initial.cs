﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Hospital.DAL.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Doctors",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Specialization = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Salary = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    PerformanceRate = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Doctors", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Issues",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Issues", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Patients",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Patients", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "IssuePatient",
                columns: table => new
                {
                    IssuesId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PatientsId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IssuePatient", x => new { x.IssuesId, x.PatientsId });
                    table.ForeignKey(
                        name: "FK_IssuePatient_Issues_IssuesId",
                        column: x => x.IssuesId,
                        principalTable: "Issues",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_IssuePatient_Patients_PatientsId",
                        column: x => x.PatientsId,
                        principalTable: "Patients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Doctors",
                columns: new[] { "Id", "Name", "PerformanceRate", "Salary", "Specialization" },
                values: new object[,]
                {
                    { new Guid("321a6e57-9493-4ca7-b091-95d0487d7e8c"), "Ahmed", 96, 70000m, "Surgery" },
                    { new Guid("554ad7f2-acab-4e67-b73d-0a0b515928e1"), "Yasmeen", 92, 80000m, "Pediatrics" },
                    { new Guid("6a6362c4-af24-44c9-bd2e-634e8283cc51"), "Maha", 99, 100000m, "Neurosurgery" },
                    { new Guid("9365646e-beda-4cae-a523-42bd81d261bf"), "Esam", 92, 77000m, "Obstetrics" },
                    { new Guid("a7adb52e-cd16-48f7-a5f2-f1695a638aa8"), "Muahmmed", 95, 50000m, "Cardiology" },
                    { new Guid("b3c989c5-a08a-4004-bd07-6a4350618eee"), "Khalid", 91, 97000m, "Radiology" },
                    { new Guid("dafe6301-5add-4efd-ba4e-f83072cd5836"), "Salma", 97, 85000m, "Pathology" }
                });

            migrationBuilder.InsertData(
                table: "Issues",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { new Guid("2101cee0-c3c1-488c-b935-5487c8a45a10"), "Headache" },
                    { new Guid("2c6b04af-efb7-4764-a71c-fe72fc4de7d4"), "Stress" },
                    { new Guid("e678e8b4-f5fe-4af5-b1ad-f4cbbf2690da"), "Cold" }
                });

            migrationBuilder.InsertData(
                table: "Patients",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { new Guid("aa214bef-6dec-4fef-86bf-cc81ed514be0"), "James" },
                    { new Guid("eaae7323-4a4d-4ab0-8407-fdc001a7bc77"), "Anderson" },
                    { new Guid("feb403f8-0f60-43d7-89f6-7ad809ebf868"), "John" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_IssuePatient_PatientsId",
                table: "IssuePatient",
                column: "PatientsId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Doctors");

            migrationBuilder.DropTable(
                name: "IssuePatient");

            migrationBuilder.DropTable(
                name: "Issues");

            migrationBuilder.DropTable(
                name: "Patients");
        }
    }
}
