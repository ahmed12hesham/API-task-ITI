﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Hospital.DAL.Migrations
{
    public partial class AddingDoctors : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("321a6e57-9493-4ca7-b091-95d0487d7e8c"));

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("554ad7f2-acab-4e67-b73d-0a0b515928e1"));

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("6a6362c4-af24-44c9-bd2e-634e8283cc51"));

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("9365646e-beda-4cae-a523-42bd81d261bf"));

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("a7adb52e-cd16-48f7-a5f2-f1695a638aa8"));

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("b3c989c5-a08a-4004-bd07-6a4350618eee"));

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("dafe6301-5add-4efd-ba4e-f83072cd5836"));

            migrationBuilder.DeleteData(
                table: "Issues",
                keyColumn: "Id",
                keyValue: new Guid("2101cee0-c3c1-488c-b935-5487c8a45a10"));

            migrationBuilder.DeleteData(
                table: "Issues",
                keyColumn: "Id",
                keyValue: new Guid("2c6b04af-efb7-4764-a71c-fe72fc4de7d4"));

            migrationBuilder.DeleteData(
                table: "Issues",
                keyColumn: "Id",
                keyValue: new Guid("e678e8b4-f5fe-4af5-b1ad-f4cbbf2690da"));

            migrationBuilder.DeleteData(
                table: "Patients",
                keyColumn: "Id",
                keyValue: new Guid("aa214bef-6dec-4fef-86bf-cc81ed514be0"));

            migrationBuilder.DeleteData(
                table: "Patients",
                keyColumn: "Id",
                keyValue: new Guid("eaae7323-4a4d-4ab0-8407-fdc001a7bc77"));

            migrationBuilder.DeleteData(
                table: "Patients",
                keyColumn: "Id",
                keyValue: new Guid("feb403f8-0f60-43d7-89f6-7ad809ebf868"));

            migrationBuilder.AddColumn<Guid>(
                name: "DoctorId",
                table: "Patients",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.InsertData(
                table: "Doctors",
                columns: new[] { "Id", "Name", "PerformanceRate", "Salary", "Specialization" },
                values: new object[,]
                {
                    { new Guid("198be7ce-61af-4b08-82a3-2c656a2d8c3e"), "Salma", 97, 85000m, "Pathology" },
                    { new Guid("19b0051a-01c9-4e9f-b2d3-3091ba49b123"), "Yasmeen", 92, 80000m, "Pediatrics" },
                    { new Guid("1a968bc0-e0a3-4904-8335-5136b00b7a3a"), "Muahmmed", 95, 50000m, "Cardiology" },
                    { new Guid("38449f89-0c5d-445e-adc7-cde9e6622912"), "Maha", 99, 100000m, "Neurosurgery" },
                    { new Guid("3c17be80-2bf7-40a0-aca3-2859cc7ac9cb"), "Ahmed", 96, 70000m, "Surgery" },
                    { new Guid("4e14f502-9124-409e-9259-16c052535ed2"), "Esam", 92, 77000m, "Obstetrics" },
                    { new Guid("e242dd81-5a8d-42a4-8e4d-3460da25fdf4"), "Khalid", 91, 97000m, "Radiology" }
                });

            migrationBuilder.InsertData(
                table: "Issues",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { new Guid("662dbcf5-5fcb-4d2b-ba7c-91c4d0267009"), "Headache" },
                    { new Guid("8da4112a-de72-492a-9cc7-375e65618328"), "Stress" },
                    { new Guid("dc111bbc-2cc2-4729-8997-c53b19ee3d17"), "Cold" }
                });

            migrationBuilder.InsertData(
                table: "Patients",
                columns: new[] { "Id", "DoctorId", "Name" },
                values: new object[,]
                {
                    { new Guid("905b97c5-0778-42dd-9996-2727693b2401"), null, "John" },
                    { new Guid("a8eac717-41ef-454b-b333-28a935becb9a"), null, "Anderson" },
                    { new Guid("c4614353-1af1-45c6-8614-285ed7e67b85"), null, "James" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Patients_DoctorId",
                table: "Patients",
                column: "DoctorId");

            migrationBuilder.AddForeignKey(
                name: "FK_Patients_Doctors_DoctorId",
                table: "Patients",
                column: "DoctorId",
                principalTable: "Doctors",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Patients_Doctors_DoctorId",
                table: "Patients");

            migrationBuilder.DropIndex(
                name: "IX_Patients_DoctorId",
                table: "Patients");

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("198be7ce-61af-4b08-82a3-2c656a2d8c3e"));

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("19b0051a-01c9-4e9f-b2d3-3091ba49b123"));

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("1a968bc0-e0a3-4904-8335-5136b00b7a3a"));

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("38449f89-0c5d-445e-adc7-cde9e6622912"));

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("3c17be80-2bf7-40a0-aca3-2859cc7ac9cb"));

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("4e14f502-9124-409e-9259-16c052535ed2"));

            migrationBuilder.DeleteData(
                table: "Doctors",
                keyColumn: "Id",
                keyValue: new Guid("e242dd81-5a8d-42a4-8e4d-3460da25fdf4"));

            migrationBuilder.DeleteData(
                table: "Issues",
                keyColumn: "Id",
                keyValue: new Guid("662dbcf5-5fcb-4d2b-ba7c-91c4d0267009"));

            migrationBuilder.DeleteData(
                table: "Issues",
                keyColumn: "Id",
                keyValue: new Guid("8da4112a-de72-492a-9cc7-375e65618328"));

            migrationBuilder.DeleteData(
                table: "Issues",
                keyColumn: "Id",
                keyValue: new Guid("dc111bbc-2cc2-4729-8997-c53b19ee3d17"));

            migrationBuilder.DeleteData(
                table: "Patients",
                keyColumn: "Id",
                keyValue: new Guid("905b97c5-0778-42dd-9996-2727693b2401"));

            migrationBuilder.DeleteData(
                table: "Patients",
                keyColumn: "Id",
                keyValue: new Guid("a8eac717-41ef-454b-b333-28a935becb9a"));

            migrationBuilder.DeleteData(
                table: "Patients",
                keyColumn: "Id",
                keyValue: new Guid("c4614353-1af1-45c6-8614-285ed7e67b85"));

            migrationBuilder.DropColumn(
                name: "DoctorId",
                table: "Patients");

            migrationBuilder.InsertData(
                table: "Doctors",
                columns: new[] { "Id", "Name", "PerformanceRate", "Salary", "Specialization" },
                values: new object[,]
                {
                    { new Guid("321a6e57-9493-4ca7-b091-95d0487d7e8c"), "Ahmed", 96, 70000m, "Surgery" },
                    { new Guid("554ad7f2-acab-4e67-b73d-0a0b515928e1"), "Yasmeen", 92, 80000m, "Pediatrics" },
                    { new Guid("6a6362c4-af24-44c9-bd2e-634e8283cc51"), "Maha", 99, 100000m, "Neurosurgery" },
                    { new Guid("9365646e-beda-4cae-a523-42bd81d261bf"), "Esam", 92, 77000m, "Obstetrics" },
                    { new Guid("a7adb52e-cd16-48f7-a5f2-f1695a638aa8"), "Muahmmed", 95, 50000m, "Cardiology" },
                    { new Guid("b3c989c5-a08a-4004-bd07-6a4350618eee"), "Khalid", 91, 97000m, "Radiology" },
                    { new Guid("dafe6301-5add-4efd-ba4e-f83072cd5836"), "Salma", 97, 85000m, "Pathology" }
                });

            migrationBuilder.InsertData(
                table: "Issues",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { new Guid("2101cee0-c3c1-488c-b935-5487c8a45a10"), "Headache" },
                    { new Guid("2c6b04af-efb7-4764-a71c-fe72fc4de7d4"), "Stress" },
                    { new Guid("e678e8b4-f5fe-4af5-b1ad-f4cbbf2690da"), "Cold" }
                });

            migrationBuilder.InsertData(
                table: "Patients",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { new Guid("aa214bef-6dec-4fef-86bf-cc81ed514be0"), "James" },
                    { new Guid("eaae7323-4a4d-4ab0-8407-fdc001a7bc77"), "Anderson" },
                    { new Guid("feb403f8-0f60-43d7-89f6-7ad809ebf868"), "John" }
                });
        }
    }
}
