﻿namespace Hospital.DAL;

public interface IDoctorsRepo : IGenericRepo<Doctor>
{
    //List<Doctor> GetAll();
    //Doctor? GetById(Guid id);
    //void Add(Doctor entity);
    //void Update(Doctor entity);
    //void Delete(Doctor entity);
    //void SaveChanges();
    List<Doctor> GetDoctorsByPerformmance(int performanceRate);
}
