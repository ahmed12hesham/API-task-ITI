﻿namespace Hospital.DAL;

public class DoctorsRepo : GenericRepo<Doctor>, IDoctorsRepo
{
    private readonly HospitalContext _context;

    public DoctorsRepo(HospitalContext context) : base(context)
    {
        _context = context;
    }

    public List<Doctor> GetDoctorsByPerformmance(int performanceRate)
    {
        return _context.Set<Doctor>().Where(d => d.PerformanceRate > performanceRate).ToList();
        //return _context.Doctors.Where(d => d.PerformanceRate > performanceRate).ToList();
    }
}
