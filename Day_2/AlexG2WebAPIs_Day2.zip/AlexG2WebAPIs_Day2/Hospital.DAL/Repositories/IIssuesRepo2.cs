﻿namespace Hospital.DAL.Repositories;

public interface IIssuesRepo2
{
    List<Issue> GetAll();
    Issue? GetById(Guid id);
    void Add(Issue entity);
    void Update(Issue entity);
    void Delete(Issue entity);
    void SaveChanges();
}
