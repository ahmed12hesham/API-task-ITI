﻿namespace Hospital.DAL;

public interface IPatientsRepo: IGenericRepo<Patient>
{
    List<Patient> GetAllWithIssues();
    List<Patient> GetAllWithDoctor();
    Patient? GetWithIssues(Guid id);
}
