﻿namespace Hospital.DAL;

public class IssuesRepo : GenericRepo<Issue>, IIssuesRepo
{
    private readonly HospitalContext _context;

    public IssuesRepo(HospitalContext context) : base(context)
    {
        _context = context;
    }

    public List<Issue> GetByIssuesIds(List<Guid> issuesIds)
    {
        // 5   =>   [ 1,5,6,8]
        return _context.Issues
            .Where(issue => issuesIds.Contains(/*الي أنا واقف عليها*/issue.Id))
            .ToList();
    }
}
