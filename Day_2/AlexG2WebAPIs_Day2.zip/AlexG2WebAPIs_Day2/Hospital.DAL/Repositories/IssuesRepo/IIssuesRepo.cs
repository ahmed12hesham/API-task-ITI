﻿namespace Hospital.DAL;

public interface IIssuesRepo : IGenericRepo<Issue>
{
    List<Issue> GetByIssuesIds(List<Guid> issuesIds); 
}
