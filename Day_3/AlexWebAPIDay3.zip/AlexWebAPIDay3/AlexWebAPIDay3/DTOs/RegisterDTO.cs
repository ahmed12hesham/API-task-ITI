﻿using System.ComponentModel.DataAnnotations;

namespace AlexWebAPIDay3.DTOs;

public class RegisterDTO
{
    [Required]
    public string Username { get; set; } = "";
    [Required]
    public string Password { get; set; } = "";
    public string Department { get; set; } = "";
}
