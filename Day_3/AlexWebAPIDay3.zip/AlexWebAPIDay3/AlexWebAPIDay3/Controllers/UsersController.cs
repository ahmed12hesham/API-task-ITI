﻿using AlexWebAPIDay3.Data;
using AlexWebAPIDay3.DTOs;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace AlexWebAPIDay3.Controllers;

[Route("api/[controller]")]
[ApiController]
public class UsersController : ControllerBase
{
    private readonly IConfiguration _configuration;
    private readonly UserManager<Employee> _userManager;

    public UsersController(IConfiguration configuration, UserManager<Employee> userManager)
    {
        _configuration = configuration;
        _userManager = userManager;
    }

    #region Static Login

    [HttpPost]
    [Route("static-login")]
    public ActionResult StaticLogin(LoginDTO loginDTO)
    {
        if (loginDTO.Username != "admin")
        {
            return Unauthorized();
        }

        var claims = new List<Claim>
        {
            new Claim("Name", loginDTO.Username),
            new Claim(ClaimTypes.NameIdentifier, "Anything")
        };

        var keyString = _configuration.GetValue<string>("SecretKey");
        var keyInBytes = Encoding.ASCII.GetBytes(keyString);
        var key = new SymmetricSecurityKey(keyInBytes);

        var signingCredentials =
            new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature);

        var jwt = new JwtSecurityToken(
            claims: claims,
            signingCredentials: signingCredentials,
            expires: DateTime.Now.AddMinutes(_configuration.GetValue<int>("tokenDuration")),
            notBefore: DateTime.Now
            );

        var tokenHandler = new JwtSecurityTokenHandler();
        var tokenString = tokenHandler.WriteToken(jwt);

        return Ok(new
        {
            Token = tokenString,
            Expiry = DateTime.Now.AddMinutes(_configuration.GetValue<int>("tokenDuration"))
        });
    }

    #endregion

    #region Register

    [HttpPost]
    [Route("register")]
    public async Task<ActionResult> Register(RegisterDTO registerDTO)
    {
        var newEmp = new Employee()
        {
            Department = registerDTO.Department,
            UserName = registerDTO.Username
        };

        var creationResult = await _userManager.CreateAsync(newEmp, registerDTO.Password);
        if (!creationResult.Succeeded)
        {
            return BadRequest(creationResult.Errors);
        }

        var claims = new List<Claim>
        {
            new Claim(ClaimTypes.NameIdentifier, newEmp.Id),
            new Claim(ClaimTypes.Role, "Engineer"),
        };

        var clainmsResult = await _userManager.AddClaimsAsync(newEmp, claims);
        if (!clainmsResult.Succeeded)
        {
            return BadRequest(clainmsResult.Errors);
        }

        return Ok();
    }

    #endregion

    #region Login 

    [HttpPost]
    [Route("login")]
    public async Task<ActionResult> Login(LoginDTO loginDTO)
    {
        var employee = await _userManager.FindByNameAsync(loginDTO.Username);

        //Check for null => 404

        if (await _userManager.IsLockedOutAsync(employee))
        {
            return BadRequest("Wait Wait");
        }

        if (!await _userManager.CheckPasswordAsync(employee, loginDTO.Password))
        {
            await _userManager.AccessFailedAsync(employee); // To increase failed attempts
            return Unauthorized();
        }

        var claims = await _userManager.GetClaimsAsync(employee);

        var keyString = _configuration.GetValue<string>("SecretKey");
        var keyInBytes = Encoding.ASCII.GetBytes(keyString);
        var key = new SymmetricSecurityKey(keyInBytes);

        var signingCredentials =
            new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature);

        var jwt = new JwtSecurityToken(
            claims: claims,
            signingCredentials: signingCredentials,
            expires: DateTime.Now.AddMinutes(_configuration.GetValue<int>("tokenDuration")),
            notBefore: DateTime.Now
            );

        var tokenHandler = new JwtSecurityTokenHandler();
        var tokenString = tokenHandler.WriteToken(jwt);

        return Ok(new
        {
            Token = tokenString,
            Expiry = DateTime.Now.AddMinutes(_configuration.GetValue<int>("tokenDuration"))
        });
    }

    #endregion
}