﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AlexWebAPIDay3.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize(Policy = "CEO")]
public class ValuesController : ControllerBase
{

    [HttpGet]
    [Authorize]
    public ActionResult GetAll()
    {
        return Ok(new List<string> { "Name", "Names" });
    }
    
    [HttpGet]
    [Route("engineer")]
    [Authorize(Policy = "Manager")]
    public ActionResult GetAllSecret()
    {
        return Ok(new List<string> { "Secret", "Secret Names" });
    }
    
    [HttpGet]
    [Route("ceo")]
    public ActionResult GetAllSecretForCEO()
    {
        return Ok(new List<string> { "CEO", "Secret Names" });
    }
    
    [HttpGet]
    [Route("none")]
    public ActionResult GetAllProducts()
    {
        return Ok(new List<string> { "Milk", "Chcken" });
    }

}
